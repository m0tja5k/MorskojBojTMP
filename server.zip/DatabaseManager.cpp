#include "DatabaseManager.h"

DatabaseManager* DatabaseManager::instance = nullptr;

DatabaseManager::DatabaseManager() {
    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("server_db.sqlite");

    if (!db.open()) {
        qDebug() << "Ошибка открытия БД:" << db.lastError().text();
    } else {
        qDebug() << "База данных подключена!";
        QSqlQuery query;
        query.exec("CREATE TABLE IF NOT EXISTS User ("
                   "login TEXT PRIMARY KEY, "
                   "password TEXT NOT NULL)");
    }
}

DatabaseManager::~DatabaseManager() {
    db.close();
}

DatabaseManager* DatabaseManager::getInstance() {
    if (!instance) {
        instance = new DatabaseManager();
    }
    return instance;
}

bool DatabaseManager::addUser(const QString &login, const QString &password) {
    QSqlQuery query;
    query.prepare("INSERT INTO User (login, password) VALUES (:login, :password)");
    query.bindValue(":login", login);
    query.bindValue(":password", password);

    if (!query.exec()) {
        qDebug() << "Ошибка добавления пользователя:" << query.lastError().text();
        return false;
    }
    return true;
}

void DatabaseManager::printUsers() {
    QSqlQuery query("SELECT * FROM User");
    while (query.next()) {
        qDebug() << "User:" << query.value(0).toString() << "Password:" << query.value(1).toString();
    }
}
