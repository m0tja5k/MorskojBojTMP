#ifndef DATABASEMANAGER_H
#define DATABASEMANAGER_H

#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>

class DatabaseManager {
public:
    static DatabaseManager* getInstance();
    bool addUser(const QString &login, const QString &password);
    void printUsers();

private:
    DatabaseManager();  // Закрытый конструктор
    ~DatabaseManager(); // Деструктор
    DatabaseManager(const DatabaseManager&) = delete;
    DatabaseManager& operator=(const DatabaseManager&) = delete;

    static DatabaseManager* instance;
    QSqlDatabase db;
};

#endif
